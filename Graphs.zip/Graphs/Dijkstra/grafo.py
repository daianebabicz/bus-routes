grafo = {
    'Terminal 1': {
		'Tubo 1': 1,
		'Ponto 1': 1,
		},
    'Tubo 1': {
		'Tubo 2': 2 - 1,
		'Ponto 2': 2 + 1,
    'Ponto 9': 9 + 1,
        },
    'Tubo 2': {
		'Tubo 3': 3 - 1,
        },
    'Tubo 3': {
		'Tubo 4': 4 - 1,
        },
    'Tubo 4': {
		'Tubo 5': 5 - 1,
        },
    'Tubo 5': {
  		'Tubo 6': 6 - 1,
        },
    'Tubo 6': {
		'Terminal 1': 1,
        },
    'Ponto 1': {
		'Tubo 2': 2 + 1,
		'Ponto 2': 2 -1,
    'Ponto 9': 9 - 1,
        },
    'Ponto 2': {
		'Ponto 3': 3 - 1,
        },
    'Ponto 3': {
		'Ponto 4': 4 - 1,
        },
    'Ponto 4': {
		'Ponto 5': 5 - 1,
        },
    'Ponto 5': {
		'Terminal 2': 2 -1,
        },
    'Ponto 6': {
		'Ponto 7': 7 -1,
        },
    'Ponto 7': {
		'Ponto 8': 8 - 1,
        },
    'Ponto 8': {
		'Ponto 9': 9 - 1,
        },
    'Ponto 9': {
		'Ponto 10': 10 - 1,
        },
    'Ponto 10': {
		'Terminal 1': 11 - 1,
        },
    'Terminal 2': {
		'Tubo 4': 4,
		'Ponto 6': 6,
        },
    }

#adicionar coordenadas + 1 pra tubo e coordenadas + 2 pra pontos
# https://algodaily.com/lessons/an-illustrated-guide-to-dijkstras-algorithm/python