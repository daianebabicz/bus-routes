from classes import *
from copy import deepcopy
from matplotlib import pyplot
import pandas as pd
import math

def tratandoCoordenadas(Nodes, nodeParaTratar):

	menor = 99.9

	for node in Nodes:
		dist = math.dist(nodeParaTratar.coordenada, node.coordenada)

		if dist < menor:
			menor = dist
			pontoEncontrado = node
		dist = 0
	
	nodeTratado = pontoEncontrado
	
	return nodeTratado

def main():

	TerminalA = Node("Terminal A", [0, 0], 'Terminal')
	TerminalB = Node("Terminal B", [9, -2], 'Terminal')
 
	# TUBO AH
	TuboA = Node("Tubo A", [3, 0], 'Tubo')
	TuboB = Node("Tubo B", [5, -1], 'Tubo')
	TuboC = Node("Tubo C", [7, -1], 'Tubo')
	
	# TUBO H
	TuboD = Node("Tubo D", [7, -2], 'Tubo')
	TuboE = Node("Tubo E", [5, -1.40], 'Tubo')
	TuboF = Node("Tubo F", [3, -1], 'Tubo')

	# PONTO AH
	PontoA = Node("Ponto A", [2, -2])
	PontoB = Node("Ponto B", [3, -3])
	PontoC = Node("Ponto C", [5, -1.60])
	PontoD = Node("Ponto D", [7, -3])
	PontoE = Node("Ponto E", [9, -2.5])

	# PONTO H
	PontoG = Node("Ponto G", [9.5, -3])
	PontoH = Node("Ponto H", [8, -4])
	PontoI = Node("Ponto I", [5, -2])
	PontoJ = Node("Ponto J", [3, -4])
	PontoK = Node("Ponto K", [1, -3])
 
	# IB
	PontoL = Node("Ponto L", [5, 0.5])
	PontoM = Node("Ponto M", [5, 1])

	Nodes = [TerminalA, TerminalB,
			TuboA, TuboB, TuboC, TuboD, TuboE, TuboF,
			PontoA, PontoB, PontoC, PontoD, PontoE,
			PontoG, PontoH, PontoI, PontoJ, PontoK,
			PontoL, PontoM]

	#Inicializando conexoes
	TerminalA.conexoes = [Edge(TerminalA, TuboA), Edge(TerminalA, PontoA), Edge(TerminalA, PontoL)]
	TerminalB.conexoes = [Edge(TerminalB, TuboD), Edge(TerminalB, PontoG), Edge(TerminalB, PontoM)]
	
	TuboA.conexoes = [Edge(TuboA, TuboB)]
	TuboB.conexoes = [Edge(TuboB, TuboC)]
	TuboC.conexoes = [Edge(TuboC, TerminalB)]
	TuboD.conexoes = [Edge(TuboD, TuboE)]
	TuboE.conexoes = [Edge(TuboE, TuboF)]
	TuboF.conexoes = [Edge(TuboF, TerminalA)]
 
	PontoA.conexoes = [Edge(PontoA, PontoB)]
	PontoB.conexoes = [Edge(PontoB, PontoC)]
	PontoC.conexoes = [Edge(PontoC, PontoD)]
	PontoD.conexoes = [Edge(PontoD, PontoE)]
	PontoE.conexoes = [Edge(PontoE, TerminalB)]

	PontoG.conexoes = [Edge(PontoG, PontoH)]
	PontoH.conexoes = [Edge(PontoH, PontoI)]
	PontoI.conexoes = [Edge(PontoI, PontoJ)]
	PontoJ.conexoes = [Edge(PontoJ, PontoK)]
	PontoK.conexoes = [Edge(PontoK, TerminalA)]
 
	PontoL.conexoes = [Edge(PontoL, TerminalB)]
	PontoM.conexoes = [Edge(PontoM, TerminalA)]
	
	# Recebendo o ponto de partida e chegada pelo usuário ao printar o mapa

	Node_Inicio, Node_Fim = plot_mapa(Nodes, setaPontos=True)

	# Monta a heuristica de acordo com a ponto destino

	print('Heurísticas:')
	for node in Nodes:
		node.gera_heuristica(Node_Fim)
		print(f"{node.ponto} - {node.get_heuristica()}")

	# Calculando a rota
	Solucao = rota(deepcopy(Node_Inicio), deepcopy(Node_Fim))
 
	# Se não existir rotas
	if not Solucao:
		pyplot.suptitle('NENHUMA ROTA ENCONTRADA', fontweight ="bold",
        		bbox={'facecolor': 'red', 'alpha': 0.6, 'pad': 4})
		plot_mapa(Nodes)
		return False
	else:
		pyplot.suptitle('MELHOR ROTA', fontweight ="bold",
        		bbox={'facecolor': 'blue', 'alpha': 0.6, 'pad': 4})
     
	# Melhor solução
	x = []
	y = []
	for node in Solucao:
		x.append(node.get_coordenada()[0])
		y.append(node.get_coordenada()[1])

	pyplot.plot(x, y, '-', color = 'red', lw=3)
	plot_mapa(Nodes)
	
def rota(Node_Inicio, Node_Fim):

	if(Node_Fim.ponto == Node_Inicio.ponto):
		return [Node_Inicio]

	Fila_De_Rotas = []

	rota = Route(Node_Inicio)
	Fila_De_Rotas.append(rota)

	while(True):
		melhores_ramos = []
		melhor_ramo = None

		index_melhores_ramos = []
		rota_com_melhor_ramo = None
		
		#Encontra o melhor ramo entre os ramos abertos
		for rota in Fila_De_Rotas:
			custo_ramos = rota.custo_ramos()
			if not custo_ramos:
				return None
				
			melhores_ramos.append(min(custo_ramos))
			index_melhores_ramos.append(custo_ramos.index(min(custo_ramos)))

		indice_melhor_rota = melhores_ramos.index(min(melhores_ramos))
		rota_com_melhor_ramo = deepcopy(Fila_De_Rotas[indice_melhor_rota])
		melhor_ramo = rota_com_melhor_ramo.ramos[index_melhores_ramos[indice_melhor_rota]]
	
		#Remove ramo da rota antiga
		rota = Fila_De_Rotas[indice_melhor_rota]
		rota.retira(melhor_ramo)
		
		rota_com_melhor_ramo.adiciona(melhor_ramo)
		Fila_De_Rotas.append(rota_com_melhor_ramo)

		#Adiciona uma nova rota ou remove uma rota que já acabou
		if(len(rota.ramos) == 0):
			Fila_De_Rotas.remove(rota)	

		#Condição de parada
		#print(rota_com_melhor_ramo)
		if(melhor_ramo.node.ponto == Node_Fim.ponto):
			break

	return rota_com_melhor_ramo.nodes
	
def plot_mapa(Nodes, setaPontos = False):

	coordenadas_x = []
	coordenadas_y = []
	for node in Nodes:
		coordenadas_x.append(node.get_coordenada()[0])
		coordenadas_y.append(node.get_coordenada()[1])

	
	# NOTE: MODO AUTOMATICO COM DIRECIONAL
	for node in Nodes:
		for conec in node.conexoes:
			pyplot.annotate("", xy=(conec.node.coordenada[0], conec.node.coordenada[1]),
                   	xytext=(node.coordenada[0], node.coordenada[1]),
					arrowprops={'arrowstyle':"->"})
 
	# NOTE: MODO AUTOMATICO SEM DIRECIONAL
	# for node in Nodes:
	# 	for conec in node.conexoes:
	# 		x = [node.coordenada[0], conec.node.coordenada[0]]
	# 		y = [node.coordenada[1], conec.node.coordenada[1]]
	# 		pyplot.plot(x, y, ':', color = 'black', lw=1)

	df = pd.DataFrame(dict(tipo=[node.tipo for node in Nodes]))
	colors = {'Terminal':'red','Ponto':'orange', 'Tubo':'yellow', 'Inicio':'blue', 'Final':'blue'}
	pyplot.scatter(coordenadas_x, coordenadas_y, marker="o", c=df['tipo'].map(colors), alpha=1)

	for node in Nodes:
		pyplot.annotate(node.ponto, xy = (node.get_coordenada()[0], node.get_coordenada()[1]))

	if setaPontos:

		Node_Inicio = Node('', [0,0])
		Node_Fim = Node('', [0,0])

		pyplot.suptitle('ESCOLHA OS PONTO DE PARTIDA E CHEGADA', fontweight ="bold",
        		bbox={'facecolor': 'ORANGE', 'alpha': 0.6, 'pad': 4})

		firstClick, secondClick = pyplot.ginput(2)
		Node_Inicio.coordenada, Node_Fim.coordenada = list(firstClick), list(secondClick)
		pyplot.show()

		Node_Inicio = tratandoCoordenadas(Nodes, Node_Inicio)
		Node_Fim = tratandoCoordenadas(Nodes, Node_Fim)

		return Node_Inicio, Node_Fim

	pyplot.show()

main()