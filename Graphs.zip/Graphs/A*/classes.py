class Node():
	def __init__(self, nome, coordenada, tipo='Ponto'):
		self.ponto = nome
		self.coordenada = coordenada
		self.heuristica = 0
		self.conexoes = []
		# Terminal, Tubo, Ponto, Inicial, Final
		self.tipo = tipo

	def gera_heuristica(self, Node_alvo):
		d = round(((self.coordenada[0] - Node_alvo.coordenada[0])**2 + (self.coordenada[1] - Node_alvo.coordenada[1])**2)**0.5, 4)
		self.heuristica = d

	def get_heuristica(self):
		return self.heuristica

	def get_coordenada(self):
		return self.coordenada

	def __str__(self):
		return self.ponto

class Edge():

	def __init__(self, node_inicio, node_alvo):
		self.node = node_alvo
		d = round(((node_inicio.coordenada[0] - node_alvo.coordenada[0])**2 + (node_inicio.coordenada[1] - node_alvo.coordenada[1])**2)**0.5, 4)
		self.distancia = d

	def custo(self):
		return self.distancia + self.node.heuristica

class Route():

	def __init__(self, Node_Inicial):
		self.distancias = 0
		#Nodes avaliados
		self.nodes = [Node_Inicial]
		#Nodes ainda não avaliados
		self.ramos = Node_Inicial.conexoes

	def custo_ramos(self):
		custo_ramos = []
		for ramo in self.ramos:
			custo_ramos.append(self.distancias + ramo.custo())

		return custo_ramos

	def adiciona(self, Ramo):
		self.distancias += Ramo.distancia
		self.nodes.append(Ramo.node)
		self.ramos = Ramo.node.conexoes

	def retira(self, Ramo):
		for ramo in self.ramos:
			if(ramo.node.ponto == Ramo.node.ponto):
				self.ramos.remove(ramo)

	def __str__(self):
		nodes = ''
		for node in self.nodes:
			nodes += "{} -> ".format(node)
   
		return nodes
		# return "{} - {}".format(nodes, self.distancias)
